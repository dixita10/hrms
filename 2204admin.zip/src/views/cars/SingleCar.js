import React from 'react'
import { useState, useEffect } from 'react'
import { Link, useParams } from 'react-router-dom'
import Loading from './Loading'
import { GiGasPump } from "react-icons/gi"
import { BsHandbagFill } from "react-icons/bs"
import { MdAirlineSeatReclineExtra } from "react-icons/md"
import { GiGearStick } from "react-icons/gi"
import { GiPathDistance } from "react-icons/gi"


export default function SingleCar() {

   const { id } = useParams()
   const url = `http://52.66.201.113/admin/car`
   const [loading, setLoading] = useState(true)
   const [car, setCar] = useState({})
   const [error, setError] = useState({ show: false, msg: '' })   
   const imageurl = 'https://speedy-cab.s3.ap-south-1.amazonaws.com/'
   // const { loading, setLoading } = useFetch()

   console.log(car)
   const fetchCar = async () => {
      const response = await fetch(`${url}/${id}`, {
         headers: { Authorization: localStorage.getItem("admin_token") }
      })
      const data = await response.json()
      console.log(data)
      if (data.response === false) {
         setError({ show: true, msg: " not found " })
         setLoading(false)
      } else {
         setCar(data.data)
         setLoading(false)
      }
   }

   useEffect(() => {
      fetchCar()
   }, [id])


   const { company, photos, model, plateno, amount, pickupaddress, dropaddress, city, type, fueltype, transmissiontype, baggage, seater } = car
   if (loading) {
      <Loading />
   }
   return (
      <div className='carcontainer'>
         <section className="section cocktail-section">

            <div className="section-title">{company}</div><br></br>
            <div className='underline'></div>
         </section >

         <div className='grid-containers'>

            <img src={`${imageurl}${photos}`} alt={company} className='carimg'></img>
            <div className='grid-items'>Pickup Address:<br></br>{pickupaddress}<div><hr />
               <div><GiPathDistance /></div>
               <hr />
               <div className='grid-item'>Dropoff Address:<br></br>{dropaddress}</div>

            </div>
            </div>

         </div>

         <div className="grid-container">

            <div class="grid-item"><GiGasPump />{fueltype}</div>
            <div class="grid-item"><MdAirlineSeatReclineExtra /> {seater}</div>
            <div class="grid-item"><GiGearStick /> {transmissiontype}</div>
            <div class="grid-item"><BsHandbagFill /> {baggage}</div>

         </div>
         <hr />
         <div className='grid-itemss'> Model : {model}</div>
         <hr />
         <div className='grid-itemss'> Type : {type}</div>
         <hr />
         <div className='grid-itemss'> Plate No : {plateno}</div>
         <hr />
         <div className='grid-itemss'> Amount : {amount}</div>
         <hr />
         <div className='grid-itemss'> City : {city}</div>
         <hr />

         <div className='grid-itemss' >
            <Link to='/cars'> <button className='btns'>Back</button></Link>
         </div>

      </div >

   )
}
