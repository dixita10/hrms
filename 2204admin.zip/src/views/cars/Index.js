import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { FaEye } from "react-icons/fa";
import paginate from "./utils";
import Loading from "./Loading";

function index() {
  const [page, setPage] = useState(0);
  const [followers, setFollowers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);

  // console.log(data);

  const getCar = async () => {
    const response = await fetch("http://52.66.201.113/admin/cars?limit=100", {
      headers: { Authorization: localStorage.getItem("admin_token") },
    });
    const data = await response.json();
    // paginate(data.provider)
    setData(paginate(data.data));
    setFollowers(data.data)
    setLoading(false);
    // console.log(data.data)
  };

  useEffect(() => {
    if (loading) return;
    setFilteredData(data[page]);
  }, [loading, page]);

  const handlePage = (index) => {
    setPage(index);
  };
  const nextbtn = () => {
    setPage((oldPage) => {
      let nextPage = oldPage + 1;
      if (nextPage > data.length - 1) {
        nextPage = 0;
      }
      return nextPage;
    });
  };

  const prevbtn = () => {
    setPage((oldPage) => {
      let prevPage = oldPage - 1;
      if (prevPage < 0) {
        prevPage = data.length - 1;
      }
      return prevPage;
    });
  };
  useEffect(() => {
    getCar();
  }, []);

  const handleSearch = (e) => {
    let value = e.target.value.toLowerCase();
    let result = [];
    console.log(value);
    result = followers.filter((data) => {
      return data._id.search(value) != -1;
    });
    setFilteredData(result);
  };

  const handleClear = () => {
    setFilteredData(followers);
  };

  if (loading) {
    return <Loading />;
  }
  return (
    <div>
      <div className="float-end">
        <input onChange={(e) => handleSearch(e)} placeholder="search..." />
        &nbsp;
        <button
          type="button"
          className="btn-clear"
          onClick={() => handleClear()}
        >
          Clear Search
        </button>
      </div>
      <table className="table">
        <thead className="table table-head">
          <tr>
            <th scope="col">Id</th>
            <th scope="col">Image</th>
            <th scope="col">Car Name</th>
            <th scope="col">Car model</th>
            <th scope="col">Car type</th>
            <th scope="col">Car Plate No.</th>
            <th scope="col">Service Provider Id</th>
            <th scope="col">City</th>
            <th scope="col">View</th>
          </tr>
        </thead>
        <tbody>
          {filteredData.length === 0
            ? 'Car not Found'
            :
            filteredData.map((follower, id) => {
              const url = "https://speedy-cab.s3.ap-south-1.amazonaws.com/";
              return (
                <tr key={id}>
                  <th scope="row">
                    <h6
                      className="truncate"
                      data-bs-toggle="tooltip"
                      data-bs-placement="bottom"
                      title={follower._id}
                    >
                      {follower._id}
                    </h6>
                  </th>
                  <td>
                    {" "}
                    <img
                      src={`${url}${follower.photos[0]}`}
                      alt={follower.company}
                      className="img"
                    />
                  </td>
                  <td>{follower.company} </td>
                  <td>{follower.model}</td>
                  <td>{follower.type}</td>
                  <td>{follower.plateno}</td>
                  <td>
                    <h6
                      className="truncate"
                      data-bs-toggle="tooltip"
                      data-bs-placement="bottom"
                      title={follower.owner}
                    >
                      {follower.owner}
                    </h6>
                  </td>
                  <td>{follower.city}</td>
                  <td>
                    {" "}
                    <div>
                      <Link to={`/cars/${follower._id}`}>
                        <button className="eye">
                          <FaEye />
                        </button>
                      </Link>
                    </div>
                  </td>
                </tr>
              );
            })}
        </tbody>
      </table>
      <div className="container">
        <button disabled={page === 0} onClick={prevbtn} className="btn-prev">
          Prev
        </button>
        {data.map((item, index) => {
          return (
            <button
              key={index}
              className={`page-btn ${index === page ? "active-btn" : null}`}
              onClick={() => handlePage(index)}
            >
              {index + 1}
            </button>
          );
        })}
        <button disabled={page === data.length - 1} onClick={nextbtn} className="btn-next">
          Next
        </button>
      </div>
    </div>
  );
}

export default index;
