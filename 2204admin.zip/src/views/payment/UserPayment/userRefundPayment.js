import React, { useState, useEffect } from "react";
import Loading from "./Loading";
import moment from "moment";
import paginate from "./utils";

export default function userRefundPayment() {
  const [page, setPage] = useState(0);
  const [followers, setFollowers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);

  // console.log(data);

  const getServiceProvider = async () => {
    const response = await fetch(
      "http://52.66.201.113/admin/user-refundpayments",
      {
        headers: { Authorization: localStorage.getItem("admin_token") },
      }
    );
    const data = await response.json();
    // paginate(data.provider)
    setData(paginate(data.data));
    setLoading(false);
    // console.log(data.data)
  };

  console.log(followers);
  useEffect(() => {
    if (loading) return;
    setFollowers(data[page]);
  }, [loading, page]);

  const handlePage = (index) => {
    setPage(index);
  };
  const nextbtn = () => {
    setPage((oldPage) => {
      let nextPage = oldPage + 1;
      if (nextPage > data.length - 1) {
        nextPage = 0;
      }
      return nextPage;
    });
  };

  const prevbtn = () => {
    setPage((oldPage) => {
      let prevPage = oldPage - 1;
      if (prevPage < 0) {
        prevPage = data.length - 1;
      }
      return prevPage;
    });
  };
  useEffect(() => {
    getServiceProvider();
  }, []);

  if (loading) {
    return <Loading />;
  }

  return (
    <div>
      <table className="table">
        <thead className="table table-head">
          <tr>
            <th scope="col">id</th>
            <th scope="col">Booking ID</th>
            <th scope="col">User ID</th>
            <th scope="col">Agent ID</th>
            <th scope="col">Payment</th>
            <th scope="col">Create Booking</th>
            <th scope="col">Status</th>
          </tr>
        </thead>
        <tbody>
          {followers.map((follower, id) => {
            return (
              <tr key={id}>
                <td>
                  <h6
                    className="truncate"
                    data-bs-toggle="tooltip"
                    data-bs-placement="bottom"
                    title={follower._id}
                  >
                    {follower._id}
                  </h6>
                </td>
                <td>
                  <h6
                    className="truncate"
                    data-bs-toggle="tooltip"
                    data-bs-placement="bottom"
                    title={follower.paymentid}
                  >
                    {follower.paymentid}
                  </h6>
                </td>
                <td>
                  <h6
                    className="truncate"
                    data-bs-toggle="tooltip"
                    data-bs-placement="bottom"
                    title={follower.bookingid}
                  >
                    {follower.bookingid}
                  </h6>
                </td>
                <td>
                  <h6
                    className="truncate"
                    data-bs-toggle="tooltip"
                    data-bs-placement="bottom"
                    title={follower.userid}
                  >
                    {follower.userid}
                  </h6>
                </td>
                <td>{follower.amount}</td>
                <td>
                  {moment(follower.createdAt).format("MMMM Do YYYY, h:mm:ss a")}
                </td>
                <td>
                  {follower.status === true ? (
                    <span className="badge rounded-pill text-success border-2 complete-label">
                      Refunded
                    </span>
                  ) : (
                    <span className="badge rounded-pill text-danger border-2 cancel-label">
                      not Refunded{" "}
                    </span>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <div className="container">
        <button disabled={page === 0} onClick={prevbtn} className="btn-prev">
          {" "}
          Prev
        </button>
        {data.map((item, index) => {
          return (
            <button
              key={index}
              className={`page-btn ${index === page ? "active-btn" : null}`}
              onClick={() => handlePage(index)}
            >
              {index + 1}
            </button>
          );
        })}
        <button disabled={page === data.length - 1} onClick={nextbtn} className="btn-next">
          Next
        </button>
      </div>
    </div>
  );
}
