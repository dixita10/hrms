
import React, { useEffect, useState } from "react";
import axios from "axios";
import moment from "moment";

function report() {
   const [data, setData] = useState([]);
   const [mvalue, setMvalue] = useState();
   const [newmonth, setNewmonth] = useState();
   const [bookinglength, setBookinglength] = useState();
   const [bookingpayment, setBookingpayment] = useState([]);


   const handleChange = (e) => {
      const { value } = e.target;
      setMvalue(value);
      let mfilter = data.filter(
         (item) => moment(item.createdAt).format("MM") === value && item.status === "paid"
      );
      setNewmonth(mfilter);
      setBookinglength(mfilter.length);
      const sumWithInitial = mfilter.reduce(
         (previousValue, currentValue) => previousValue + currentValue.payment, 0
      );
      setBookingpayment(sumWithInitial);
      console.log(mfilter);
   };

   const getdata = () => {
      axios
         .get("http://52.66.201.113/admin/bookings?limit=500 ", {
            headers: { Authorization: localStorage.getItem("admin_token") },
         })
         .then((res) => {
            console.log(res.data.data);
            setData(res.data.data);
         })
         .catch((error) => {
            console.log(error);
         });
   };
   useEffect(() => {
      getdata();
   }, []);
   return (
      <div>
         <div
            style={{
               background: "#f1f1f1",
               marginRight: " 1.7rem",
               marginLeft: "1.6rem",
               borderRadius: "6px",
               marginBottom: "2rem",
            }}
         >
            <select
               class="form-select"
               aria-label="Default select example"
               value={mvalue}
               onChange={handleChange}
            >
               <option selected>Select Month</option>
               <option>01</option>
               <option>02</option>
               <option>03</option>
               <option>04</option>
               <option>05</option>
               <option>06</option>
               <option>07</option>
               <option>08</option>
               <option>09</option>
               <option>10</option>
               <option>11</option>
               <option>12</option>
            </select>
            <div className="report-total">
               <h5>Total Booking <br />  <span>{bookinglength && bookinglength ? bookinglength : "0"}</span></h5>
               <h5>Total Payment <br /> <span className="float-end">{bookingpayment && bookingpayment ? bookingpayment : "0"}</span> </h5>

            </div>
            <div>
               <table className="table">
                  <thead>
                     <tr>
                        <th scope="col">_id</th>
                        <th scope="col">S_pid</th>
                        <th scope="col">userid</th>
                        <th scope="col">carid</th>
                        <th scope="col">carname</th>
                        <th scope="col">payment</th>
                        <th scope="col">status</th>
                     </tr>
                  </thead>
                  <tbody>
                     {newmonth && newmonth.length === 0
                        ? "THERE WILL BE NO BOOKING FOUND FOR THIS MONTH"
                        : newmonth &&
                        newmonth.map((item, id) => {
                           return (
                              <tr key={id}>
                                 <td>
                                    <h6
                                       className="truncate"
                                       data-bs-toggle="tooltip"
                                       data-bs-placement="bottom"
                                       title={item._id}
                                    >
                                       {item._id}
                                    </h6>
                                 </td>
                                 <td>
                                    <h6
                                       className="truncate"
                                       data-bs-toggle="tooltip"
                                       data-bs-placement="bottom"
                                       title={item.agentid}
                                    >
                                       {item.agentid}
                                    </h6>
                                 </td>
                                 <td>
                                    <h6
                                       className="truncate"
                                       data-bs-toggle="tooltip"
                                       data-bs-placement="bottom"
                                       title={item.userid}
                                    >
                                       {item.userid}
                                    </h6>
                                 </td>
                                 <td>
                                    <h6
                                       className="truncate"
                                       data-bs-toggle="tooltip"
                                       data-bs-placement="bottom"
                                       title={item.carid}
                                    >
                                       {item.carid}
                                    </h6>
                                 </td>

                                 <td>{item.car_name}</td>
                                 <td>{item.payment}</td>
                                 <td>
                                    {item.status === "paid" ? (
                                       <>
                                          <span className="badge rounded-pill text-success border-2 complete-label">
                                             paid
                                          </span>
                                       </>
                                    ) : (
                                       <>
                                          <span className="badge rounded-pill text-danger border-2 cancel-label">
                                             cancelled{" "}
                                          </span>
                                       </>
                                    )}
                                 </td>
                                 <td></td>
                              </tr>
                           );
                        })}
                  </tbody>
               </table>
            </div>
         </div>
      </div>
   );
}

export default report;