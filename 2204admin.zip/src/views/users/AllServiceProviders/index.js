import React, { useState, useEffect } from "react";
import moment from "moment";
import Loading from "./Loading";
import axios from "axios";
import paginate from "./utils";

function index() {
  // const { loading, data, getServiceProvider } = useFetch();
  const [page, setPage] = useState(0);
  const [all, setAll] = useState([]);
  const [status, setStatus] = useState([]);
  const [followers, setFollowers] = useState([]);
  const [statusChange, setStatusChange] = useState(0);
  const [checkStatus, setCheckStatus] = useState([]);
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [filteredData, setFilteredData] = useState(followers);
  const [activeButton, setActiveButton] = useState("all");


  // console.log(followers);
  const getServiceProvider = async () => {
    setLoading(true);
    const response = await fetch(
      "http://52.66.201.113/admin/all-users?limit=100&filter=2",
      {
        headers: { Authorization: localStorage.getItem("admin_token") },
      }
    );
    const data = await response.json();
    // paginate(data.provider)
    setData(paginate(data.data));
    setFilteredData(data.data);
    setLoading(false);

    // console.log(data.data)
  };

  useEffect(() => {
    if (loading) return;
    setFollowers(data[page]);
  }, [loading, page]);

  const handlePage = (index) => {
    setPage(index);
  };
  const nextbtn = () => {
    setPage((oldPage) => {
      let nextPage = oldPage + 1;
      if (nextPage > data.length - 1) {
        nextPage = 0;
      }
      return nextPage;
    });
  };

  const prevbtn = () => {
    setPage((oldPage) => {
      let prevPage = oldPage - 1;
      if (prevPage < 0) {
        prevPage = data.length - 1;
      }
      return prevPage;
    });
  };

  const handleAll = (e) => {
    setLoading(true);
    axios
      .get("http://52.66.201.113/admin/all-users?limit=100&filter=2", {
        headers: { Authorization: localStorage.getItem("admin_token") },
      })
      .then((res) => {
        setFilteredData(res.data.data);
        setLoading(false);
        const { name } = e.target;
        setActiveButton(name);

      });
  };

  const handleBLock = (e) => {
    setLoading(true);
    axios
      .get("http://52.66.201.113/admin/all-users?filter=2&status=1", {
        headers: { Authorization: localStorage.getItem("admin_token") },
      })
      .then((res) => {
        setFilteredData(res.data.data);
        setLoading(false);
        const { name } = e.target;
        setActiveButton(name);

      });
  };

  const handleUnBlock = (e) => {

    setLoading(true);
    axios
      .get("http://52.66.201.113/admin/all-users?filter=2&status=2", {
        headers: { Authorization: localStorage.getItem("admin_token") },
      })
      .then((res) => {
        setFilteredData(res.data.data);
        setLoading(false);
        const { name } = e.target;
        setActiveButton(name);

      });
  };

  const handleClick = async (id, status) => {
    if (status === "blocked") {
      await fetch(`http://52.66.201.113/admin/deblock-user/${id}`, {
        method: "PATCH",
        headers: {
          Authorization: localStorage.getItem("admin_token"),
        },
      })
        .then((res) => {
          if (res.status === 200) {
            getServiceProvider();
          }
        })
        .catch((err) => {
          console.log(err);
        });
    }
    if (status === "allowed") {
      await fetch(`http://52.66.201.113/admin/block-user/${id}`, {
        method: "PATCH",
        headers: {
          Authorization: localStorage.getItem("admin_token"),
        },
      })
        .then((res) => {
          // status === 'blocked';
          console.log(res);
          if (res.status === 200) {
            getServiceProvider();
          }
        })
        .catch((err) => {
          console.log(err);
        });
    }
    // console.log(statusChange)
  };

  const handleSearch = (e) => {
    let value = e.target.value.toLowerCase();
    let result = [];
    console.log(value);
    result = followers.filter((data) => {
      return data._id.search(value) != -1;
    });
    setFilteredData(result);
  };

  const handleClear = () => {
    setFilteredData(followers);
  };

  useEffect(() => {
    getServiceProvider();
  }, []);

  if (loading) {
    return <Loading />;
  }
  return (
    <div>
      <div>
        <button className={activeButton === "all" ? "activebtn" : "btns"} name='all' onClick={handleAll}>
          All
        </button>
        <button className={activeButton === "block" ? "activebtn" : "btns"} name='block' onClick={handleUnBlock}>
          Block
        </button>
        <button className={activeButton === "unblock" ? "activebtn" : "btns"} name='unblock' onClick={handleBLock}>
          Unblock
        </button>
        <div className="float-end">
          <input onChange={(e) => handleSearch(e)} placeholder="search..." />
          &nbsp;
          <button
            type="button"
            className="btn-clear"
            onClick={() => handleClear()}
          >
            Clear Search
          </button>
        </div>
      </div>
      <table className="table">
        <thead className="table table-head">
          <tr>
            <th scope="col">id</th>
            <th scope="col">Name</th>
            <th scope="col">Email Id</th>
            <th scope="col">Phone No.</th>
            <th scope="col">Birth Date</th>
            <th scope="col">Status</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
          {filteredData.length === 0
            ? 'User not Found'
            :
            filteredData.map((follower, id) => {
              const bdate = moment(follower.dob).format("DD/MM/YYYY");

              return (
                <tr key={id}>
                  <th scope="row">
                    <h6
                      className="truncate"
                      data-bs-toggle="tooltip"
                      data-bs-placement="bottom"
                      title={follower._id}
                    >
                      {follower._id}
                    </h6>
                  </th>
                  <td>{follower.name} </td>
                  <td>{follower.email}</td>
                  <td>{follower.phno}</td>
                  <td>{bdate}</td>
                  <td>
                    {follower.status === "allowed" ? (
                      <span className="badge rounded-pill text-success border-2 complete-label">
                        {follower.status}
                      </span>
                    ) : (
                      <span className="badge rounded-pill text-danger border-2 cancel-label">
                        {follower.status}
                      </span>
                    )}
                  </td>

                  <td>
                    <button
                      onClick={() => handleClick(follower._id, follower.status)}
                    >
                      {follower.status === "allowed" ? (
                        <button type="button" class="btn btn-danger btn-sm">
                          Block
                        </button>
                      ) : (
                        <button type="button" class="btn btn-success btn-sm">
                          Unblock
                        </button>
                      )}
                    </button>
                  </td>
                </tr>
              );
            })}
        </tbody>
      </table>
      <div className="container">
        <button disabled={page === 0} onClick={prevbtn} className="btn-prev">
          Prev
        </button>
        {data.map((item, index) => {
          return (
            <button
              key={index}
              className={`page-btn ${index === page ? "active-btn" : null}`}
              onClick={() => handlePage(index)}
            >
              {index + 1}
            </button>
          );
        })}
        <button disabled={page === data.length - 1} onClick={nextbtn} className="btn-next">
          Next
        </button>
      </div>
    </div>
  );
}
export default index;
