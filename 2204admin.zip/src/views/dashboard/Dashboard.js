import React, { useState, lazy, useEffect } from 'react'
import ReactApexChart from 'react-apexcharts'
import axios from 'axios'
import moment from 'moment'
import { useHistory } from 'react-router-dom'
const WidgetsDropdown = lazy(() => import('../widgets/WidgetsDropdown.js'))
// const WidgetsBrand = lazy(() => import('../widgets/WidgetsBrand.js'))

const Dashboard = () => {
  const [data, setData] = useState([])
  const [mDate, setmDate] = useState()

  const history = useHistory()

  const getdata = () => {
    axios.get("http://52.66.201.113/admin/bookings?limit=500 ", {
      headers: { Authorization: localStorage.getItem("admin_token") }
    })
      .then(res => {
        setData(res.data.data)
        // console.log(res.data.data)
      })
      .catch((error) => {
        if (error.response.data.status === false) {
          history.push("/login")
        }
      })
  }

  useEffect(() => {
    getdata()
  }, [])

  let date = [(data.map((item) => moment(item.createdAt).format("YYYY-MM-DD")))]
  let newDate = Array.from(...new Set(date))
  // const uniqueDate = newDate.filter()
  // console.log(newDate)


  const occurrences = newDate.reduce(function (acc, curr) {
    return acc[curr] ? ++acc[curr] : acc[curr] = 1, acc
  }, {});
  // console.log(occurrences)
  // console.log(++acc[curr])


  //acess key
  // for (var key in occurrences) {
  //   console.log(key)
  //   console.log(occurrences[key])
  // }

  // console.log(mDate)

  const series = [{
    name: 'Booking',
    data: (Object.values(occurrences))
  }]

  const options = {
    chart: {
      height: 400,
      type: 'area'
    },
    dataLabels: {
      enabled: false
    },
    stroke: {
      curve: 'smooth'
    },
    xaxis: {
      type: 'datetime',
      // categories: [...new Set(data.map((item) => moment(item.createdAt).format("YYYY-MM-DD")))]
      categories: (Object.keys(occurrences))
    },
    tooltip: {
      x: {
        format: 'dd/MM/yy '
      },
    },
  }

  return (
    <>
      < WidgetsDropdown />
      <ReactApexChart options={options} series={series} type="area" height={400} />
    </>
  )

}


export default Dashboard
