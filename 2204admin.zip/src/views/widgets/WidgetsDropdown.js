import React, { useState } from 'react'
import {
  CRow,
  CCol,
  CDropdown,
  CDropdownMenu,
  CDropdownItem,
  CDropdownToggle,
  CWidgetStatsA,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilOptions } from '@coreui/icons'
import axios from 'axios'
import { useEffect } from 'react'
import { Link } from 'react-router-dom'
import moment from 'moment'
import Loading from './Loading'

const WidgetsDropdown = () => {
  const [data, setData] = useState([])
  const [enduser, setEnduser] = useState([])
  const [sp, setsp] = useState([])
  const [booking, setBooking] = useState([])
  const [car, setCar] = useState([])
  const [book, setBook] = useState([])
  const [loading, setLoading] = useState(true)
  const [admin, setAdmin] = useState()

  const today = moment().format("YYYY-MM-DD")
  // console.log(admin);
  var temp = 0;
  var temp1 = 0;


  const countUser = () => {
    setLoading(true)
    axios.get("http://52.66.201.113/admin/all-users?limit=500 ", {
      headers: { Authorization: localStorage.getItem("admin_token") }
    })
      .then(res => {
        setData(res.data.data)
        countAdmin(res.data.data)
        setLoading(false)
        // console.log(res.data.data.role)
      })
      .catch((error) => {
        console.log(error.response)
      })



    axios.get("http://52.66.201.113/admin/all-users?limit=500&filter=1 ", {
      headers: { Authorization: localStorage.getItem("admin_token") }
    })
      .then(res => {
        setEnduser(res.data.data)
        setLoading(false)

      })


    axios.get("http://52.66.201.113/admin/all-users?limit=500&filter=2 ", {
      headers: { Authorization: localStorage.getItem("admin_token") }
    })
      .then(res => {
        setsp(res.data.data)
        setLoading(false)

      })

    axios.get("http://52.66.201.113/admin/bookings?limit=500 ", {
      headers: { Authorization: localStorage.getItem("admin_token") }
    })
      .then(res => {
        setBooking(res.data.data)
        fetchdate(res.data.data)
        setLoading(false)

        // console.log(res.data.data)
      })


    axios.get("http://52.66.201.113/admin/cars?limit=100 ", {
      headers: { Authorization: localStorage.getItem("admin_token") }
    })
      .then(res => {
        setCar(res.data.data)
        setLoading(false)

        // console.log(car)
      })
  }

  const fetchdate = (book) => {

    book.map((bdata, id) => {
      const { createdAt } = bdata
      const date = moment(createdAt).format("YYYY-MM-DD")
      // console.log(date)
      if (date === today) {
        temp = temp + 1
      }
    })
    setBook(temp)
  }

  const countAdmin = (data) => {
    data.map((item, id) => {
      const { role } = item
      if (role === "admin") {
        temp1 = temp1 + 1
      }
    })
    setAdmin(temp1)
  }
  // console.log(countAdmin)
  useEffect(() => {
    countUser()
  }, [])

  return (
    <CRow>
      <CCol sm={6} lg={3} >
        <CWidgetStatsA
          className="mb-4"
          style={{ height: '6rem', backgroundColor: '#8eaeca' }}
          // color="primary"
          value={
            <>
              Users
            </>
          }
          title=
          {loading ? <Loading /> : data.length - admin}

          action={
            <CDropdown alignment="end">
              <CDropdownToggle color="transparent" caret={false} className="p-0">
                <CIcon icon={cilOptions} className="text-high-emphasis-inverse" />
              </CDropdownToggle>
              <CDropdownMenu style={{ background: '#e4e6e8' }}>
                <CDropdownItem style={{ color: '#8eaeca' }}>
                  <Link to='/users/all-enduser' style={{
                    textDecoration: 'none', color: '#8eaeca'
                  }} >All Endusers ({enduser.length})</Link>
                </CDropdownItem>
                <CDropdownItem><Link to='/users/all-serviceprovider' style={{ textDecoration: 'none', color: '#8eaeca' }} >All ServiceProvider ({sp.length})</Link>
                </CDropdownItem>
              </CDropdownMenu>
            </CDropdown>
          }
        />
      </CCol>

      <CCol sm={6} lg={3}>
        <CWidgetStatsA
          className="mb-4"
          style={{ height: '6rem', backgroundColor: '#c08b94' }}
          // color="info"
          value={
            <>
              All Booking
            </>
          }
          title={loading ? <Loading /> : booking.length}
        />
      </CCol>

      <CCol sm={6} lg={3}>
        <CWidgetStatsA
          className="mb-4"
          style={{ height: '6rem', backgroundColor: '#6f788c' }}
          // color="warning"
          value={
            <>
              All Cars
            </>
          }
          title={loading ? <Loading /> : car.length}

        />
      </CCol>

      <CCol sm={6} lg={3}>
        <CWidgetStatsA
          className="mb-4"
          style={{ height: '6rem', backgroundColor: '#c5c3c3' }}
          // color="danger"
          value={
            <>
              Booking Today
            </>
          }

          title={
            <>
              {loading ? <Loading /> : book}

            </>
          }
        />
      </CCol>
    </CRow>
  )
}

export default WidgetsDropdown
