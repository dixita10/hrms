import React, { useState, useEffect } from "react";
import Loading from "./Loading";
import { Label, Input } from "reactstrap";
import { Button, Modal, FormGroup } from "react-bootstrap";
import { FaEye, FaEdit } from "react-icons/fa";
import paginate from "./utils";
import axios from "axios";
// import moment from 'moment';

function index() {
  // const { loading, data } = useFetch();
  const [page, setPage] = useState(0);
  const [followers, setFollowers] = useState([]);
  const [show, setShow] = useState(false);
  const [display, setDisplay] = useState(false);
  const [singleComplain, setSingleComplain] = useState([]);
  const [isValue, setIsValue] = useState();
  const [status, setStatus] = useState();
  const [res, setRes] = useState();
  const [newFollowers, setNewFollowers] = useState([]);
  const [modalLoading, setModalLoading] = useState(true);
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [inProcess, setInProcess] = useState([]);
  const [secondLoading, setSecondloading] = useState(false);
  const [filteredData, setFilteredData] = useState(followers);
  const [activeButton, setActiveButton] = useState("all");
  // const [randomNo, setRandomNo] = useState([0])
  console.log(activeButton)
  const getComplint = async () => {
    setLoading(true);
    axios
      .get("http://52.66.201.113/admin/complaints", {
        headers: { Authorization: localStorage.getItem("admin_token") },
      })
      .then((res) => {
        setData(paginate(res.data.data));
        setFilteredData(res.data.data)
        console.log(res.data.data);
        setLoading(false);
      })
      .catch((error) => {
        setLoading(false);
        console.log(error.response);
      });
  };

  // send response
  const handleRemove = () => {
    setDisplay(false);
  };
  const handleDisplay = (id) => {
    setDisplay(true);
    console.log(id);
    const newId = followers.find((item) => item._id === id);
    setNewFollowers(newId);
  };

  const handleReview = (id) => {
    console.log(id);
    let passedData = {
      status: status,
      response: res,
    };
    axios
      .post(`http://52.66.201.113/admin/complaint-reply/${id}`, passedData, {
        headers: {
          Authorization: localStorage.getItem("admin_token"),
        },
      })
      .then((response) => {
        console.log(response.data);
        if (response.data.status === true) {
          alert("your response added");
          handleRemove();
          getComplint();
        }
      })
      .catch((error) => {
        console.log(error.data);
      });
  };

  //view complaint
  const handleClose = () => setShow(false);
  const handleShow = (id) => {
    setShow(true);
    console.log(id);
    setModalLoading(true);
    axios
      .get(`http://52.66.201.113/admin/complaint/${id}`, {
        headers: { Authorization: localStorage.getItem("admin_token") },
      })
      .then((response) => {
        // console.log(response);
        if (response.data.status === true) {
          setSingleComplain(response.data.data);
          console.log(response.data.data);
        }
        setModalLoading(false);
      })
      .catch((error) => {
        console.log(error.response);
        setLoading(false);
      });
  };

  useEffect(() => {
    if (loading) return;
    setFollowers(data[page]);
  }, [loading, page]);

  const handlePage = (index) => {
    setPage(index);
  };
  const nextbtn = () => {
    setPage((oldPage) => {
      let nextPage = oldPage + 1;
      if (nextPage > data.length - 1) {
        nextPage = 0;
      }
      return nextPage;
    });
  };

  const prevbtn = () => {
    setPage((oldPage) => {
      let prevPage = oldPage - 1;
      if (prevPage < 0) {
        prevPage = data.length - 1;
      }
      return prevPage;
    });
  };
  const handleAll = (e) => {
    setSecondloading(true);
    axios
      .get("http://52.66.201.113/admin/complaints", {
        headers: { Authorization: localStorage.getItem("admin_token") },
      })
      .then((res) => {
        setFilteredData(res.data.data);
        // setFollowers(inProcess)
        console.log(res.data.data);
        setSecondloading(false);
        const { name } = e.target;
        setActiveButton(name);

      });

  };

  const handleInprocees = (e) => {
    setSecondloading(true);
    axios
      .get("http://52.66.201.113/admin/complaints?status=in-process", {
        headers: { Authorization: localStorage.getItem("admin_token") },
      })
      .then((res) => {
        setFilteredData(res.data.data);
        // setFollowers(inProcess)
        console.log(res.data.data);
        setSecondloading(false);
        const { name } = e.target;
        setActiveButton(name);

      });
  };

  const handlepending = (e) => {
    setSecondloading(true);

    axios
      .get("http://52.66.201.113/admin/complaints?status=pending", {
        headers: { Authorization: localStorage.getItem("admin_token") },
      })
      .then((res) => {
        setFilteredData(res.data.data);
        setSecondloading(false);
        const { name } = e.target;
        setActiveButton(name);
      });
  };

  const handlesolved = (e) => {
    setSecondloading(true);

    axios
      .get("http://52.66.201.113/admin/complaints?status=solved", {
        headers: { Authorization: localStorage.getItem("admin_token") },
      })
      .then((res) => {
        setFilteredData(res.data.data);
        setSecondloading(false);
        const { name } = e.target;
        setActiveButton(name);
      });
  };

  const handleSearch = (e) => {
    let value = e.target.value.toLowerCase();
    let result = [];
    console.log(value);
    result = followers.filter((data) => {
      return data._id.search(value) != -1;
    });
    setFilteredData(result);
  };

  const handleClear = () => {
    setFilteredData(followers);
  };

  useEffect(() => {
    getComplint();
  }, []);

  if (loading) {
    return <Loading />;
  }
  if (secondLoading) {
    return <Loading />;
  }
  return (
    <div>
      <div>
        <button className={activeButton === "all" ? "activebtn" : "btns"} name="all" onClick={handleAll}>
          All
        </button>
        <button className={activeButton === "inprocess" ? "activebtn" : "btns"} name="inprocess" onClick={handleInprocees}>
          In-Process
        </button>
        <button className={activeButton === "pending" ? "activebtn" : "btns"} name="pending" onClick={handlepending}>
          Pending
        </button>
        <button className={activeButton === "solved" ? "activebtn" : "btns"} name="solved" onClick={handlesolved}>
          Solved
        </button>
        <div className="float-end">
          <input onChange={(e) => handleSearch(e)} placeholder="search..." />
          &nbsp;
          <button
            type="button"
            className="btn-clear"
            onClick={() => handleClear()}
          >
            Clear Search
          </button>
        </div>
      </div>
      <table className="table">
        <thead className="table table-head">
          <tr>
            <th scope="col">Id</th>
            <th scope="col">UserID</th>
            <th scope="col">Regarding</th>
            <th scope="col">Ref ID</th>
            <th scope="col">Complaintby</th>
            <th scope="col">Subject</th>
            <th scope="col">Status</th>
            <th scope="col">View</th>
          </tr>
        </thead>
        <tbody>
          {
            filteredData.length === 0
              ? 'Compliant not Found'
              :
              filteredData.map((follower, id) => {
                return (
                  <tr key={id}>
                    <th scope="row">
                      <h6
                        className="truncate"
                        data-bs-toggle="tooltip"
                        data-bs-placement="bottom"
                        title={follower._id}
                      >
                        {follower._id}
                      </h6>
                    </th>
                    <td>
                      <h6
                        className="truncate"
                        data-bs-toggle="tooltip"
                        data-bs-placement="bottom"
                        title={follower.userid}
                      >
                        {follower.userid}
                      </h6>
                    </td>
                    <td>{follower.regard}</td>
                    <td>
                      <h6
                        className="truncate"
                        data-bs-toggle="tooltip"
                        data-bs-placement="bottom"
                        title={follower.refid}
                      >
                        {follower.carid || follower.refid}
                      </h6>
                    </td>
                    <td>{follower.complaintby}</td>
                    <td>
                      <b> {follower.subject}</b>
                    </td>
                    <td className={follower.status}>
                      <label className={`${follower.status} label-status`}>
                        {follower.status}
                      </label>
                    </td>

                    <td>
                      <button
                        className="btn"
                        onClick={() => handleShow(follower._id)}
                        data-toggle="tooltip"
                        data-placement="bottom"
                        title="view complain"
                      >
                        <FaEye style={{ fontSize: "1.5rem" }} />
                      </button>

                      <button
                        className="btn"
                        onClick={() => handleDisplay(follower._id)}
                        data-toggle="tooltip"
                        data-placement="bottom"
                        title="Reply complain"
                      >
                        <FaEdit style={{ fontSize: "1.2rem" }} />
                      </button>
                    </td>
                  </tr>
                );
              })}
        </tbody>
      </table>

      {/* view modal */}
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>View Complain</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {modalLoading ? (
            <div class="d-flex justify-content-center">
              <div class="spinner-border" role="status">
                <span class="sr-only"></span>
              </div>
            </div>
          ) : (
            <div>
              <label>
                <h6>Subject</h6>
              </label>
              <br />
              <input
                className="complain-input"
                type="text"
                value={singleComplain && singleComplain.subject}
              ></input>
              <br />
              <br />
              <label>
                <h6>Message</h6>
              </label>
              <br />
              <input
                className="complain-input"
                type="text"
                value={singleComplain && singleComplain.message}
              ></input>
              <br />
              <br />

              {singleComplain && singleComplain.status === "solved" ? (
                <>
                  {" "}
                  <label>
                    <h6>Solution</h6>
                  </label>
                  <br />
                  <textarea
                    className="complain-input"
                    value={singleComplain && singleComplain.response}
                  ></textarea>
                </>
              ) : null}

              {/* <h1>{singleComplain && singleComplain._id}</h1> */}
            </div>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>

      {/* edit model */}
      <Modal show={display} onHide={handleRemove}>
        <Modal.Header closeButton>
          <Modal.Title> Complain solved</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {/* <h3>{followers && followers._id}</h3> */}
          <FormGroup>
            <Label for="type">Status</Label>
            <Input
              type="select"
              name="type"
              onChange={(e) => setStatus(e.target.value)}
              value={status}
            >
              <option>Choose Status...</option>
              <option>pending</option>
              <option>in-process</option>
              <option>solved</option>
            </Input>
          </FormGroup>
          <br />
          <FormGroup>
            <Label for="exampleText">Complain reply</Label>
            <Input
              type="textarea"
              name="text"
              id="exampleText"
              value={res}
              onChange={(e) => setRes(e.target.value)}
            />
          </FormGroup>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleRemove}>
            Close
          </Button>
          <Button
            variant="primary"
            onClick={() => handleReview(newFollowers._id)}
          >
            Submit
          </Button>
        </Modal.Footer>
      </Modal>

      <div className="container">
        <button disabled={page === 0} onClick={prevbtn} className="btn-prev">
          Prev
        </button>
        {data.map((item, index) => {
          return (
            <button
              key={index}
              className={`page-btn ${index === page ? "active-btn" : null}`}
              onClick={() => handlePage(index)}
            >
              {index + 1}
            </button>
          );
        })}
        <button disabled={page === data.length - 1} onClick={nextbtn} className="btn-next">
          Next
        </button>
      </div>
    </div >
  );
}

export default index;
