import React, { useState, useEffect } from "react";
import Loading from "./Loading";
import moment from "moment";
import paginate from "./utils";
import axios from "axios";

function index() {
  const [page, setPage] = useState(0);
  const [followers, setFollowers] = useState();
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [mvalue, setMvalue] = useState();

  let today = moment().format("YYYY-MM-DD");

  const getBooking = () => {
    setLoading(true);
    axios
      .get("http://52.66.201.113/admin/bookings?limit=500", {
        headers: { Authorization: localStorage.getItem("admin_token") },
      })
      .then((response) => {
        var data = response?.data?.data?.map((header, index) => {
          if (header.status === "cancelled") {
            return { ...header, st: "cancelled" };
          }
          if (
            today >= moment(header.checkin).format("YYYY-MM-DD") &&
            today <= moment(header.checkout).format("YYYY-MM-DD")
          ) {
            return { ...header, st: "ongoing" };
          } else if (today > header.checkout) {
            if (header.status === "cancelled") {
              return { ...header, st: "cancelled" };
            } else {
              return { ...header, st: "completed" };
            }
          } else if (header.checkin > today) {
            if (header.status === "cancelled") {
              return { ...header, st: "cancelled" };
            } else {
              return { ...header, st: "pre-booked" };
            }
          }
        });

        setData(paginate(data));
        setFollowers(data)
        setLoading(false);
      })
      .catch((error) => {
        console.log(error.response.data.status);
        // if (error.response.data.status) {
        // }
        setLoading(false);
      });
  };
  useEffect(() => {
    if (loading) return;
    setFilteredData(data[page]);
  }, [loading, page]);

  const handlePage = (index) => {
    setPage(index);
  };
  const nextbtn = () => {
    setPage((oldPage) => {
      let nextPage = oldPage + 1;
      if (nextPage > data.length - 1) {
        nextPage = 0;
      }
      return nextPage;
    });
  };

  const prevbtn = () => {
    setPage((oldPage) => {
      let prevPage = oldPage - 1;
      if (prevPage < 0) {
        prevPage = data.length - 1;
      }
      return prevPage;
    });
  };
  const handleSearch = (e) => {
    let value = e.target.value.toLowerCase();
    let result = [];
    console.log(value);
    result = followers.filter((data) => {
      return data._id.search(value) != -1;
    });
    setFilteredData(result);
  };

  const handleClear = () => {
    setFilteredData(followers);
    handleSearch("")
  };

  const handleChange = (e) => {
    const { value } = e.target;
    console.log(value)
    setMvalue(value);
    let mfilter = followers.filter(
      (item) => item.st === value
    );
    setFilteredData(mfilter);
  };

  useEffect(() => {
    getBooking();
  }, []);

  if (loading) {
    return <Loading />;
  }
  return (
    <div>
      <div className="booking-header">
        <div>
          <select
            class="form-select"
            aria-label="Default select example"
            value={mvalue}
            onChange={handleChange}
          >
            <option selected>Select Status</option>
            <option>completed</option>
            <option>pre-booked</option>
            <option>ongoing</option>
            <option>cancelled</option>

          </select>
        </div>
        <div className="float-end">

          <input onChange={(e) => handleSearch(e)} placeholder="search..." />
          &nbsp;
          <button
            type="button"
            className="btn-clear"
            onClick={() => handleClear()}
          >
            Clear Search
          </button>
        </div>
      </div>
      <table className="table">
        <thead className="table table-head">
          <tr>
            <th scope="col">Id</th>
            <th scope="col">Car ID</th>
            <th scope="col">User ID</th>
            <th scope="col">Service Provider ID</th>
            <th scope="col">Checkin Date</th>
            <th scope="col">ChechOut Date</th>
            <th scope="col">Amount</th>
            <th scope="col">Create Booking</th>
            <th scope="col">Status</th>
          </tr>
        </thead>
        <tbody>
          {filteredData.length === 0
            ? 'There is no Booking Found'
            : filteredData.map((follower, id) => {
              let checkindate = moment(follower.checkin).format("DD/MM/YYYY");
              let checkoutdate = moment(follower.checkout).format(
                "DD/MM/YYYY"
              );

              return (
                <tr key={id}>
                  <th
                    scope="row"
                    data-bs-toggle="tooltip"
                    data-bs-placement="bottom"
                    title={follower._id}
                  >
                    <h6 className="truncate">{follower._id}</h6>
                  </th>
                  <td>
                    <h6
                      className="truncate"
                      data-bs-toggle="tooltip"
                      data-bs-placement="bottom"
                      title={follower.carid}
                    >
                      {follower.carid}
                    </h6>
                  </td>
                  <td>
                    <h6
                      className="truncate"
                      data-bs-toggle="tooltip"
                      data-bs-placement="bottom"
                      title={follower.userid}
                    >
                      {follower.userid}
                    </h6>
                  </td>
                  <td>
                    <h6
                      className="truncate"
                      data-bs-toggle="tooltip"
                      data-bs-placement="bottom"
                      title={follower.agentid}
                    >
                      {follower.agentid}
                    </h6>
                  </td>
                  <td>{checkindate}</td>
                  <td>{checkoutdate}</td>
                  <td>{follower.payment}</td>
                  <td>
                    {moment(follower.createdAt).format(
                      "MMMM Do YYYY, h:mm:ss a"
                    )}
                  </td>
                  <td >
                    <label className={follower.st} >{follower.st}</label>
                  </td>
                </tr>
              );
            })}
        </tbody>
      </table>
      <div className="container">
        <button disabled={page === 0} onClick={prevbtn} className="btn-prev">
          {" "}
          Prev
        </button>
        {data.map((item, index) => {
          return (
            <button
              key={index}
              className={`page-btn ${index === page ? "active-btn" : null}`}
              onClick={() => handlePage(index)}
            >
              {index + 1}
            </button>
          );
        })}
        <button disabled={page === data.length - 1} onClick={nextbtn} className="btn-next">
          Next
        </button>
      </div>
    </div>
  );
}

export default index;
